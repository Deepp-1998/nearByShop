import { Component } from '@angular/core';

@Component({
  selector: 'app-grocery-shop',
  templateUrl: './grocery-shop.component.html',
  styleUrls: ['./grocery-shop.component.scss']
})
export class GroceryShopComponent {

}
